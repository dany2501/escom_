#include <sys/socket.h>
#include <linux/if_packet.h>
#include <net/ethernet.h> /* the L2 protocols */
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <string.h>
#include <sys/time.h>
#include <string.h>
#include <sys/socket.h>
#include <net/if_arp.h>
#include <linux/if_ether.h>
#include <net/ethernet.h> 
#include <math.h>
unsigned char MACOrigen[6];
unsigned char IPOrigen[4];
unsigned char mascaraRed[4];
unsigned char IPDestino[4];
unsigned char DireccionRed[4];
unsigned char tramaResp[1514];
unsigned char ethertype[2]={0x08, 0x06};
unsigned char codigo[2]={0x00, 0x02};
int bitscadena[8];
unsigned char tramaEnv[60]={0xff,0xff,0xff,0xff,0xff,0xff,0x00,0x00,0x00,0x00,
0x00,0x00,0x08,0x06,0x00,0x01,0x08,0x00,0x06,0x04,
0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,'E','S','B'};


void convertirABinario(unsigned char *cadena, int posicion);
int convertirADecimal(int *cadena);
void RecibeARPRespuesta(int ds, unsigned char *trama);


int obtenerDatos(int ds){
	struct ifreq nic;
    	unsigned char interface[20];
    	int i, index;
    	printf("\nInserta el nombre de la interfaz: ");
    	gets(interface);
    	strcpy(nic.ifr_name, interface);
    	if (ioctl(ds, SIOCGIFINDEX, &nic) == -1)
    	{
        	perror("\n Error al obtener el index");
        	exit(0);
    	}
    	else
    	{
        	index = nic.ifr_ifindex;
        	printf("\n>>El indice es: %d \n", index);
        	if (ioctl(ds, SIOCGIFHWADDR, &nic) == -1){
            		perror("\n Error al obtener la MAC");
            		exit(0);
        	}
        	else{
            		memcpy(MACOrigen, nic.ifr_hwaddr.sa_data, 6);
            		printf("\n>>La MAC es: ");
            		for (i = 0; i < 6; i++){
                		printf("%.2x:", MACOrigen[i]);
            		}
            		printf("\n");
        	}
        		if (ioctl(ds, SIOCGIFNETMASK, &nic) == -1){
            			perror("Error al obtener la Máscara de subred");
            			exit(0);
        		}
        			else{
            				memcpy(mascaraRed, nic.ifr_netmask.sa_data + 2, 4);
            				printf("\n>>La Mascara de Subred es: ");
            				for (int i = 0; i < 4; i++){
                				printf("%d.", mascaraRed[i]);
            				}
            				printf("\n");
        			}
        			if (ioctl(ds, SIOCGIFADDR, &nic) == -1){
            				perror("Error al obtener la direccion ip");
            				exit(0);
        			}
        				else{
            					memcpy(IPOrigen, nic.ifr_addr.sa_data + 2, 4);
           					printf("\n>>La direccion IP es: ");
            					for (int i = 0; i < 4; i++){
                					printf("%d.", IPOrigen[i]);
            					}
            			
        				}
    }
    return index;
}


void obtenIPD(){
	int i, ip1;
	printf("\n\n>>Ingrese IP de destino: ");
	for(i = 0; i < 3; i++){
		IPDestino[i] = IPOrigen[i];
		printf("%d.", IPDestino[i]);
	}
	scanf("%d", &ip1);
	IPDestino[3] = ip1;
}


void obtenDireccionRed(){
	int bitsIPorigen[8];
	int bitsMascaraSubred[8];
	int cadena[8];
	int i, j, a, b, c;
	
	for(i = 0; i < 4; i++){
		convertirABinario(IPOrigen, i);
		for(j = 0; j < 8; j++)
			bitsIPorigen[j] = bitscadena[j];
		convertirABinario(mascaraRed, i);
		for(j = 0; j < 8; j++)
			bitsMascaraSubred[j] = bitscadena[j];
		for(j = 0; j < 8; j++){
			a = bitsIPorigen[j];
			b = bitsMascaraSubred[j];
			c = a&b;
			cadena[j] = c;
		}
		DireccionRed[i] = convertirADecimal(cadena);
	}
	printf("Direccion de Red: ");
	for(i = 0; i < 4; i++)
		printf("%d.", DireccionRed[i]);
}


void estructuraSolArp(unsigned char *trama){
	memcpy(trama+6, MACOrigen, 6);
	memcpy(trama+22, MACOrigen, 6);
	memcpy(trama+28, IPOrigen, 4);
	memset(trama+32, 0x00, 6);
	memcpy(trama+38, DireccionRed, 4);
}


void enviarTrama(int ds, int indice, unsigned char *trama){
	int tam;
	struct sockaddr_ll capaEnlace;
	memset(&capaEnlace, 0x00, sizeof(capaEnlace));
	capaEnlace.sll_family = AF_PACKET;
	capaEnlace.sll_protocol = htons(ETH_P_ALL);
	capaEnlace.sll_ifindex = indice;
	tam=sendto(ds, trama, 60, 0, (struct sockaddr*)&capaEnlace, sizeof(capaEnlace));
	if(tam == -1){
		perror("\nErrror al enviar trama");
		exit(1);
	}
	else{
		perror("\nExito al enviar trama");
	}
}

void imprimirTrama(unsigned char *trama, int tam){
	int i;

	for(i=0; i<tam; i++)
	{
		if(i%16==0)
			printf("\n");
		printf("%.2x ", trama[i]);
	}
}

int main(){
	int packet_socket, indice, i, j;
	packet_socket = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if(packet_socket == -1){
		perror("\nError al abrir el socket");
		exit(1);
	}
	else{
		perror("\nExito al abrir el socket");
		indice = obtenerDatos(packet_socket);
		obtenIPD();
		obtenDireccionRed();
		for(i = 1; i < 255; i++){
			DireccionRed[3] = i;	
			printf("\n>>Direccion de Red: ");
			for(j = 0; j < 4; j++){
				printf("%d.", DireccionRed[j]);
			}
			estructuraSolArp(tramaEnv);
			printf("\n**********Trama a enviar**********");
			imprimirTrama(tramaEnv,60);
			printf("\n");
			enviarTrama(packet_socket, indice, tramaEnv);
			RecibeARPRespuesta(packet_socket, tramaResp);
		}
	}
	close(packet_socket);
	return 0;
}


void convertirABinario(unsigned char *cadena, int posicion){
	int i, r; 
	r = cadena[posicion];
	if(r == 0){
		for(i = 0; i <= 7; i++)
    		bitscadena[7-i] = 0;	
	}
	else if(r == 1){
		bitscadena[7] = 1;
		for(i = 1; i <= 7; i++)
			bitscadena[7-i] = 0;	
	}
	else{
		for(i = 0; i < 7; i++){
			bitscadena[7-i] = r%2;	
			r = r/2;
			if(r == 1){
				i++;
				bitscadena[7-i] = r;
				if(i < 7){
					i++;
					while(i <= 7){
						bitscadena[7-i] = 0;
						i++;
					}
				}
			}
		}
    }
}


int convertirADecimal(int *cadena){
	int i;
	int suma = 0;
	for(i = 0; i < 8; i++){
		if(cadena[i] == 1)
			suma += pow(2, 7-i);
		if(cadena[i] == 0)
			suma += 0;
	}
	return suma;
}


void RecibeARPRespuesta(int ds, unsigned char *trama){
	FILE *fp = fopen("TramaRecibida.txt", "w+");
	struct timeval start, end;
    	long mtime=0, seconds, useconds;
	int tam, bandera;
	gettimeofday(&start, NULL);
	while(mtime < 200){
		bandera = 0;
		tam = recvfrom(ds, trama, 1514, MSG_DONTWAIT, NULL, 0);
		if(!memcmp(trama+0, MACOrigen, 6)){
			if(!memcmp(trama+12, ethertype, 2)){
				if(!memcmp(trama+20, codigo, 2)){
					if(!memcmp(trama+28, DireccionRed, 4)){
						printf("\n**********Trama recibida***********");
						imprimirTrama(trama, tam);
						fprintf(fp, "\n**********Trama recibida**********");
						
                                		printf("\n");
						bandera = 1;
					}
				}
			}
		}		
	gettimeofday(&end, NULL);
    	seconds  = end.tv_sec  - start.tv_sec;
        useconds = end.tv_usec - start.tv_usec;
    	mtime = ((seconds) * 1000 + useconds/1000.0) + 0.5;
	if(bandera == 1)
		break;
	}
	
	printf("\nTiempo transcurrido: %ld milisegundos\n\n\n", mtime);
	fprintf(fp, "\nTiempo transcurrido: %ld milisegundos\n\n", mtime);
	fclose(fp);
	
}
