#include "BisonP.tab.h"

int main(){
 
yyparse();	/* sintactico */

return 0;

}
